const firstName = "ALEX";
console.log(typeof firstName);
const firstNameElement = document.querySelector("#firstName");
console.log(`DAG` + firstName);
firstNameElement.innerText = firstName;

function getRandomjouwGetal() {
  const box = document.querySelector("#jouwGetal");
  const jouwGetal = Math.floor(Math.random() * 100) + 1;
  box.textContent = jouwGetal;
}
getRandomjouwGetal();

function getRandomColor() {
  const box = document.querySelector("#jouwKleur");
  const randomColor = "#" + Math.floor(Math.random() * 16777215).toString(16);
  box.style.backgroundColor = randomColor;
  box.style.borderRadius = "50%";
  box.textContent = "";
}
getRandomColor();

let trekkingen = +sessionStorage.trekkingen + 1 || 1;
sessionStorage.trekkingen = trekkingen;
window.onload = () =>
  (document.getElementById("aantalTrekkingenNummer").textContent = trekkingen);
